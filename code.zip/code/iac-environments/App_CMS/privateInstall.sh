#!/bin/bash

read -rp "subscription_Id: "  subscription_Id
read -rp "tenent_Id: "  tenant_Id
read -rp "clien_Id: " client_Id
read -rp "client_secret: " client_secret
read -rp "Full Name: [firstname lastname]" full_name
read -rp "workspace: " workspace

#tfvars
tfvarsFile="private.tfvars"

#script directory
script_dir="$( cd "$( dirname "$0" )" && pwd )"

function SetEnvironmentalVariables {
  export TF_VAR_client_id=$client_Id;
  export TF_VAR_client_secret=$client_secret;
  export TF_VAR_subscription_id=$subscription_Id;
  export TF_VAR_tenant_id=$tenant_Id;
  export TF_VAR_installers_name=$full_name;
}

function RemoveBackendFile {
  cd "$script_dir" || exit
  mv backend.tf backend.tf.bak
}

function PlaceBackendFile {
  cd "$script_dir" || exit
  mv backend.tf.bak backend.tf
}

function  RunTerraformJob {
  cd "$script_dir" || exit

  terraform init
  terraform workspace new "$workspace";
  terraform workspace select "$workspace";
  terraform plan --var-file="$tfvarsFile";

  read -rp 'Apply Terraform plan? [yes]: ' apply;

  if [ "$apply" == "yes" ]
  then
      terraform apply --var-file="$tfvarsFile" --auto-approve;
      read -rp 'Press any key to continue ...'
  else
      printf "Cancelled";
      read -rp 'Press any key to continue ...'
  fi
}

printf "***********************************************\n";
printf "";
printf "Installing Parameters: \n"
printf "Subscription:  %s\n" "$subscription_Id"
printf "Tenant Id:  %s\n" "$tenant_Id"
printf "Client Id:  %s\n" "$client_Id"
printf "Client Secret:  %s\n" "$client_secret"
printf "Full Name:  %s\n" "$full_name"
printf "Workspace: %s\n" "$workspace"

read -rp "Proceed with Installation [yes]: " Confirmation

if [ "$Confirmation" == "yes" ]
then
  printf "Deploying...\n\n"
  printf "Setting up environment variables...\n"
  SetEnvironmentalVariables
  RemoveBackendFile
  RunTerraformJob
  PlaceBackendFile
else
  printf "Cancelled"
  read -rp 'Press any key to continue ...'
fi