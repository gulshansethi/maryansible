Param (
    [Parameter(Mandatory=$True)]
    [String]$subscription_Id,

    [Parameter(Mandatory=$True)]
    [String]$tenant_Id,

    [Parameter(Mandatory=$True)]
    [String]$client_Id,

    [Parameter(Mandatory=$True)]
    [String]$client_secret,

    [Parameter(Mandatory=$True)]
    [String]$full_name,

    [Parameter(Mandatory=$True)]
    [String]$workspace
)

#tfvars
$tfvarsFile = "private.tfvars";

function SetEnvironmentalVariables {
    $env:TF_VAR_client_id = $client_Id;
    $env:TF_VAR_client_secret = $client_secret;
    $env:TF_VAR_subscription_id = $subscription_Id;
    $env:TF_VAR_tenant_id = $tenant_Id;
    $env:TF_VAR_installers_name = $full_name;
}

function RemoveBackendFile {
  cd $PSScriptRoot;
  Rename-Item -Path "backend.tf" -NewName "backend.tf.bak"
}

function PlaceBackendFile {
  cd $PSScriptRoot;
  Rename-Item -Path "backend.tf.bak" -NewName "backend.tf"
}

function RunTerraformJob {
    cd $PSScriptRoot;

    terraform init
    terraform workspace new $workspace;
    terraform workspace select $workspace;
    terraform plan --var-file="$tfvarsFile";

    $Apply = Read-Host -Prompt 'Apply Terraform plan? [yes]';

    If ($Apply.ToLower() -eq "yes") {
        terraform apply --var-file="$tfvarsFile" --auto-approve;
        Write-Host "Press any key to continue ..."
        $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } else {
        write-Output "Cancelled";
        Write-Host "Press any key to continue ..."
        $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
}

Write-output "***********************************************";
Write-output "";
Write-output "Installing Parameters: ";
Write-Output "Subscription:  $subscription_Id";
Write-Output "Tenant Id:  $tenant_Id";
Write-Output "Client Id:  $client_Id";
Write-Output "Client Secret:  $client_secret";
Write-Output "Full Name:  $full_name";
Write-Output "Workspace:  $workspace";


$Confirmation = Read-Host -Prompt 'Proceed with Installation [yes]';

If ($Confirmation.ToLower() -eq "yes") {
    Write-Output "Deploying...";
    Write-Output "";
    Write-Output "Setting up environment variables...";
    SetEnvironmentalVariables;
    RemoveBackendFile;
    RunTerraformJob;
    PlaceBackendFile;
} else {
    write-Output "Cancelled";
    Write-Host "Press any key to continue ..."
    $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}