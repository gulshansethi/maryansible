Terraform versions
-
For Terraform 0.12. 

Description
-
Deployment of CMS (Umbraco) Resource Group and the required services.

Deployment
-
**Private**
- App Service
- App Service Plan
- Application Insights
- SQL Server
- SQL Database
- Action Groups
- Alert Rule
- Key Vault
- Azure Storage

**SIT (And Others)**
- App Service
- App Service Plan
- Application Insights
- SQL Server
- SQL Database
- Action Groups
- Alert Rule
- Key Vault
- Azure Storage

Private Environment Requirements
-
- Client ID
- Client Secret
- Tenant ID
- Subscription

Private Installation
-
**Mac/Linux:**
1. open terminal
2. cd into the App_Oculos directory
3. run the following command `chmod +x privateInstall.sh`
4. run the following command `./privateinstall.sh`

**Windows**
1. right click on privateInstall.ps1
2. click on "Run with PowerShell"

Troubleshoot
-
[PowerShell not running](https://www.itprotoday.com/powershell/running-powershell-scripts-easy-1-2-3)





