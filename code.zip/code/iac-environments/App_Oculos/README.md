Terraform versions
-
For Terraform 0.12. 

Description
-
Deployment of Oculos (AKS) Resource Group and the required services.  This allows for implementation of Microservices
running via containers (docker).

Deployment
-
**Private**
- Kubernetes Service
- API Management Service
- Application Insights
- Service Bus Namespace
- SQL Server
- SQL Database
- Container Registry
- Virtual Network
- Redis Cache
- Search Service
- Frontdoor
- Logic App

**SIT (And Others)**
- Kubernetes Service
- API Management Service
- Application Insights
- Service Bus Namespace
- SQL Server
- SQL Database
- Redis Cache
- Search Service
- Frontdoor
- Logic App

Private Environment Requirements
-
- Client ID
- Client Secret
- Tenant ID
- Subscription

Private Installation
-
**Mac/Linux:**
1. open terminal
2. cd into the App_Oculos directory
3. run the following command `chmod +x privateInstall.sh`
4. run the following command `./privateinstall.sh`

**Windows**
1. right click on privateInstall.ps1
2. click on "Run with PowerShell"

Troubleshoot
-
[PowerShell not running](https://www.itprotoday.com/powershell/running-powershell-scripts-easy-1-2-3)





